$(document).ready(function () {

  $('#btn-enviar').on('click', function() {
    $('.form-tarjeta').addClass('was-validated');
  });

  $('.form-tarjeta').on('submit', function (event) {
    event.preventDefault();
    var datosFormulario = $(this).serialize();

    window.location = "./paso-2.html?" + datosFormulario;
  });

});